# Zupt — Findings Ledger (2.x series)

Single durable record of audit findings against Zupt 2.x. New findings
append at the bottom. Status transitions update in-place.

Numbering: F-NN, monotonic, never reused.

---

## F-01 — `zupt help` formatting: `keygen` line missing newline  [STATUS: fixed]
Severity: low (UX, not security)
Discovered: 2026-05-19, sprint 2.2.4-kickoff
Component: src/zupt_main.c:41

### Reproducer
```sh
./zupt help | sed -n '/^  zupt keygen/p'
# Before: "  zupt keygen                            Key generation  zupt version"
# After:  "  zupt keygen                            Key generation"
```

### Root cause
The string literal at `src/zupt_main.c:41` ends `"Key generation"` (no
`\n`), so the following literal `"  zupt version\n"` concatenates onto
the same line via C string adjacency. Caught by visual inspection of
`./zupt help`.

### Fix
`src/zupt_main.c:41` — append `\n` to the `keygen` line.

### Regression test
`tests/run_quick.sh` gains a check that `./zupt help` outputs exactly
one line per `^  zupt ` command (10 lines, one per command verb).

### Verification
- `diff` of `./zupt help` before/after shows one extra newline.
- Regression line `[ "$(./zupt help | grep -c '^  zupt ')" -ge 10 ]`
  passes after fix, fails on the buggy build.

---

## F-02 — Flaky `make test`: tamper test ~10% failure rate; unauthenticated index region  [STATUS: fixed]
Severity: medium (one test flake, one real auth-coverage gap)
Discovered: 2026-05-19, sprint 2.2.4-kickoff
Component: tests/test_audit.sh:38-52  +  design issue in src/zupt_format.c

### Reproducer
```sh
# Run the audit test 50× standalone — observe ~5 failures.
for i in $(seq 1 50); do
    bash tests/test_audit.sh 2>&1 | grep -q 'Tamper.*A=1 B=0' && echo "fail $i"
done
```

Failure mode: B=0 means the byte flipped at `len-50` did not get
rejected on extract — the tampered archive successfully extracted.

### Root cause
The PQ-SDK archive sizes 1769 / 1770 / 1771 bytes depending on encoded
ciphertext-length variance. When the archive is 1771 bytes,
`len - 50 = 1721`, which lands inside the **index region** between
`index_offset = 1618` (read from the footer) and footer-start at
`1771 - sizeof(zupt_footer_t) = 1739`.

Confirmed via:
```
last 32 footer breakdown:
  idx=1618 blocks=1 cksum=0x06cb magic=ZEND ver=1
  → index region is bytes 1618..1738 (121 bytes)
  → byte 1721 is inside this region
```

The index region is **not** covered by the per-block HMAC scheme.
Per-block HMAC covers `nonce || ciphertext` of each data block, but
the index of `(path, offset, length)` tuples written between the last
block and the footer is plain bytes. A flipped bit there changes
file metadata without invalidating any HMAC. The archive checksum in
the footer is a simple length/cksum field, not a cryptographic MAC
over the index.

### Fix (two parts)

**Part A — make the test deterministic** (this sprint, F-02a):
Tamper at byte `header_size + 16` (offset 80 — inside the first
data block's `nonce||ciphertext`), guaranteed authenticated by
per-block HMAC. Cover both ends with two new check points (early-body
and late-body), neither relative to file length.

**Part B — close the auth-coverage gap** (deferred to 2.2.5, F-02b):
Compute `index_mac = HMAC-SHA256(mac_key, index_bytes || footer[0:24])`
and store it in the unused 12-byte `reserved` field of
`zupt_archive_header_t` (extending to a separate footer-MAC trailer if
12 bytes proves insufficient). Verify on extract before parsing the
index. This requires a `FORMAT.md` coverage-table update and a format
version bump from v1.4 → v1.5 with backward-compat read path.

This finding splits into F-02a (test) and F-02b (format) because the
format change is too large for a patch release.

### Regression test
`tests/test_audit.sh` rewritten: A2 tampers at byte 80 (early-body),
new check A2b tampers at `header_size + last_block_offset + 16`
(late-body). Both run 50× in `tests/test_audit_flake.sh` to enforce
the §3 mandate.

### Verification
- `for i in $(seq 1 50); do bash tests/test_audit.sh; done` → 50/50 pass.
- The original `len-50` reproducer still flips the index byte, but
  is now run as a *known-unauthenticated* probe in
  `tests/test_format_coverage.sh` that documents Part B's open status.

---

## F-03 — `-Wshadow`: local `r` shadows in zupt_secure_random  [STATUS: fixed]
Severity: info (cosmetic; both `r`s coincidentally hold a count)
Discovered: 2026-05-19, sprint 2.2.4-kickoff
Component: src/zupt_crypto.c:48,54

### Reproducer
```sh
CC=gcc CFLAGS="-Wall -Wextra -Wshadow -O2 -std=c11" make 2>&1 \
    | grep -F 'src/zupt_crypto.c'
# warning: declaration of 'r' shadows a previous local [-Wshadow]
```

### Root cause
Line 48 declares `ssize_t r = syscall(SYS_getrandom, …)` inside a
`#if defined(__linux__)` block. Line 54 declares `size_t r = fread(…)`
in the surrounding function scope, fallback path. The Linux `r` is
inside a conditional, so the surrounding `r` is technically the
shadower of *nothing* in the false branch, but GCC reports the
warning when the inner scope is entered.

### Fix
Rename the `fread` result to `nread`. The Linux `r` keeps its name
since it directly maps to the getrandom syscall return.

### Regression test
The strict-warning build configs in `§6` of PROMPT.md catch this.
No new test file; the existing baseline check is sufficient.

### Verification
GCC strict build is clean after the rename.

---

## F-04 — `zupt_mlkem768_selftest` missing prototype, no callers  [STATUS: fixed]
Severity: info (dead code or missing wiring)
Discovered: 2026-05-19, sprint 2.2.4-kickoff
Component: src/zupt_mlkem.c:648; not declared in any header

### Reproducer
```sh
grep -rn zupt_mlkem768_selftest include/ src/
# Only the definition appears. No declaration, no caller.
CC=gcc CFLAGS="-Wmissing-prototypes" make 2>&1 | grep -F selftest
# warning: no previous prototype for 'zupt_mlkem768_selftest'
```

### Root cause
The function was added as a sanity check during ML-KEM bring-up but
was never wired into a test target or exposed via the header. It
performs a real NTT roundtrip and CBD-sample property check that is
genuinely useful — wire it in rather than delete it.

### Fix
- Declare `int zupt_mlkem768_selftest(void);` in
  `include/zupt_mlkem.h`.
- Add a call in `tests/test_vectors.c` as a 14th NIST/RFC-vector
  case ("ML-KEM-768 internal self-test").
- Update `AUDIT.md` test-vector count from 13 → 14.

### Regression test
`make test-vectors` now executes the self-test as case 14. Fails the
suite if `zupt_mlkem768_selftest()` returns 0.

### Verification
- Strict GCC build clean.
- `make test-vectors` → 14/14 PASS (was 13/13).

---

## F-05 — cppcheck: three uint8_t* pointers can be const  [STATUS: fixed]
Severity: info (style)
Discovered: 2026-05-19, sprint 2.2.4-kickoff
Component: src/vv_ans.c:1575, 2228, 2265

### Reproducer
```sh
cppcheck --enable=all --suppress=missingIncludeSystem \
    --suppress=unusedFunction --std=c11 -Iinclude -Isrc src/*.c \
    2>&1 | grep -F constVariablePointer
```

Three sites flagged:
- `vv_ans.c:1575`: `uint8_t *best_buf = NULL;`
- `vv_ans.c:2228`: `uint8_t *op_end = dst + dst_cap;`
- `vv_ans.c:2265`: `uint8_t *op_safe_end = (...)`

### Root cause
These pointers are used only as one-past-end sentinels for bounds
checks; never written through. Constness adds documentation value and
lets the compiler reject accidental writes in future edits.

### Fix
Change each to `const uint8_t *`.

### Regression test
Future cppcheck runs in the §6 audit pass.

### Verification
- `cppcheck --enable=all` clean for these three sites after the patch.
- VaptVupt is GPL-3.0-or-later — patch headers preserved.

---

## F-02b — Authenticate the archive index region  [STATUS: resolved-by-F-06]
Severity: was medium; reclassified after root cause identified
Status: closed — the framing was wrong
Component: src/zupt_format.c + include/zupt.h (format change)
Closed: 2026-05-19, sprint 2.2.5

### Re-investigation outcome

The 2.2.4 hypothesis was that the archive index region was not covered
by any MAC. The 2.2.5 exhaustive byte sweep of a 1771-byte `--pq-sdk`
archive showed three positions where tampering went undetected:

| Position | Field | Was it actually unauthenticated? |
|---|---|---|
| 1620 | index block_type byte | yes (parser-trivia) — fixed by F-07 |
| 1624 | index block_flags high byte | yes (reserved/unused) — accepted as `OPAQUE` |
| 1713 | inside index HMAC region | **NO — the index IS MAC'd; the HMAC verifier was buggy** |

Position 1713 unmasked F-06 (HMAC accept-on-disjoint-bits). The index
region IS MAC'd correctly during encryption — the bug was in
`zupt_decrypt_buffer`'s combined-diff logic, which silently accepted
~6% of single-bit MAC tampers on the Jasmin (x86_64) path.

No format change is required. F-02b is closed without v1.5 bump.
The cosmetic-metadata bytes that remain unauthenticated (header
timestamps, UUIDs, reserved fields, etc.) are tracked as the lower-
severity F-08, deferred to v2.3.0.

---

## F-06 — HMAC verifier silently accepts ~6% of single-bit MAC tampers (Jasmin path)  [STATUS: fixed]
Severity: **high** (integrity-bypass on production x86_64 path)
Discovered: 2026-05-19, sprint 2.2.5
Component: src/zupt_crypto.c:442 (`zupt_decrypt_buffer`)

### Reproducer (live archive)

```sh
# Build a 1771-byte --pq-sdk archive (size 1771 puts the test position
# inside the index block's HMAC region).
for i in $(seq 1 100); do
    rm -f k.priv k.priv.pub a.zupt t.zupt; mkdir -p out; rm -rf out/*
    ./zupt keygen --sdk -o k.priv >/dev/null
    echo "data" > input.txt
    ./zupt c --pq-sdk k.priv.pub a.zupt input.txt >/dev/null
    cp a.zupt t.zupt
    python3 -c "
b=bytearray(open('t.zupt','rb').read()); b[len(b)-50]^=1
open('t.zupt','wb').write(bytes(b))"
    (cd out && ../zupt x --pq-sdk ../k.priv ../t.zupt >/dev/null 2>&1)
    [ -f out/input.txt ] && echo "FAIL $i"
done
# Pre-2.2.5: ~2 fails per 100 trials (limited by ~25% size-1771 hit rate;
# inside that subset, ~6% of single-bit HMAC tampers were accepted).
# Post-2.2.5: 0 fails per 200 trials.
```

### Reproducer (unit test, exercises HMAC path directly)

`make test-f06` runs 2000 trials with a 1-bit MAC flip rotating across
all 256 bit positions of the HMAC. Pre-fix: ~127/2000 silent accepts
(~6.35%). Post-fix: 0/2000.

### Root cause

The Encrypt-then-MAC verifier computes two candidate MACs — `v2` with
AAD-bound block_seq, `v1` legacy without — and accepts iff at least
one matches. The combined-diff expression was:

```c
uint64_t diff_v2 = zupt_mac_verify_ct(expected_mac_v2, stored_mac);  /* Jasmin */
uint64_t diff_v1 = zupt_mac_verify_ct(expected_mac_v1, stored_mac);  /* Jasmin */
...
uint64_t diff = diff_v2 & diff_v1;  /* BUG */
```

`zupt_mac_verify_ct` (Jasmin, `jasmin/zupt_mac_verify.jazz`) returns a
**full 64-bit accumulator**: it loads 4×u64 little-endian chunks of
each MAC, XORs each chunk pair, and ORs the results into a single
u64. So `diff_vX` is non-zero iff that MAC mismatched, and the
accumulator holds the bitwise-OR of the four XOR chunks.

The author's intent was "accept iff either MAC was zero (matched)".
The expression `diff_v2 & diff_v1` only realises that intent when at
least one operand is *fully* zero. When BOTH operands are non-zero —
i.e. both MACs mismatched, i.e. tamper occurred — `diff_v2 & diff_v1`
is still 0 whenever the two diffs have disjoint nonzero bits.

For a 1-bit MAC flip:
- `diff_v2` has exactly one of 64 bits set.
- `diff_v1` is OR-of-4-random-u64s ≈ mostly-saturated, leaving on
  average 4 bit-positions unset out of 64.
- `diff_v2 & diff_v1 == 0` iff the single set bit lands on one of
  those ~4 unset positions: probability ~4/64 ≈ 6.25%.

Empirically: 127/2000 = 6.35% silent-accept rate in the unit test.

The C-fallback path (`#ifndef ZUPT_USE_JASMIN`) accumulates each
byte-XOR into a u64 via `|=`, so each `diff_vX` only occupies the
low 8 bits. The probability that two non-zero 8-bit values have
disjoint bits is much lower but still non-zero. Both paths are
buggy in principle; only the Jasmin (production x86_64) path is
exploitable in practice.

### Fix

`src/zupt_crypto.c:438-444` — collapse each diff to a single
nonzero-indicator bit before ANDing, constant-time:

```c
uint64_t nz_v2 = (diff_v2 | (uint64_t)(-(int64_t)diff_v2)) >> 63;  /* CT-REQUIRED */
uint64_t nz_v1 = (diff_v1 | (uint64_t)(-(int64_t)diff_v1)) >> 63;  /* CT-REQUIRED */
uint64_t diff = nz_v2 & nz_v1;
```

`(x | -x) >> 63` is the standard branchless "is nonzero" indicator:
0 → 0, anything else → 1. No data-dependent branch, no
secret-dependent memory access. The final `diff` is 0 iff at least
one MAC matched, which is the original intent.

Both the C-fallback path and the Jasmin path use the same fix shape
to prevent future re-divergence.

### Regression test

`tests/test_f06_hmac.c` + Makefile target `test-f06`. Constructs 2000
independent encrypt-then-decrypt pairs with rotating 1-bit MAC flips;
asserts zero silent acceptances. Demonstrably catches the bug — when
the fix is reverted, the test reports ~127/2000 silent accepts.

### Verification

- `make test-f06` — 2000/2000 trials, 0 silent accepts (post-fix).
- Reverting the fix → test reports 127/2000 silent accepts → fails.
- 200 live `--pq-sdk` archive tamper trials at byte `len-50` — 200/200
  rejected (was 198/200 pre-fix; the gap matched ~6% × ~25% size-hit).
- Exhaustive byte sweep of all 121 index-region bytes of a 1771-byte
  archive: post-fix, 0 silent accepts in that region (was 3 pre-fix
  at byte 1713 — the HMAC tail).
- `make test` — 61/61 passing.
- `make test-vectors` — 14/14 passing.
- Strict GCC `-Wshadow -Wcast-align -Wstrict-prototypes
  -Wmissing-prototypes -Wnull-dereference -Wformat-security
  -Wlogical-op -Wjump-misses-init -Wdouble-promotion`: clean.
- Strict Clang same set: clean.
- ASAN `--pq-sdk` roundtrip on 12-file source tree: byte-exact.

### Severity calibration

Classified **high** but not **critical** because:

- The attacker cannot forge MACs with chosen content. The bug is
  "this random tamper might not be detected", not "the attacker can
  produce arbitrary authenticated ciphertext".
- The success probability is ~6% per 1-bit flip; multi-bit tampers
  decrease this exponentially (the more bits set in `diff_v2`, the
  more of `diff_v1`'s unset positions they need to all land on).
- The plaintext is not recoverable — at-rest encryption keys remain
  protected.
- However, the bug breaks the integrity guarantee SECURITY.md makes
  ("any modification is detected with overwhelming probability"), so
  it must ship as a patch release.

---

## F-07 — open_archive() did not verify block_type at index_offset  [STATUS: fixed]
Severity: low (closes one OPAQUE-class byte; not exploitable on its own)
Discovered: 2026-05-19, sprint 2.2.5
Component: src/zupt_format.c (`open_archive`, just after `read_block`)

### Reproducer

Build a 1771-byte `--pq-sdk` archive (any size will do — the bug is
position-independent), flip byte at offset `index_offset + 2`
(the block_type byte of the index block), extract. Pre-fix:
extraction succeeds. Post-fix: extraction fails with
`ZUPT_ERR_CORRUPT`.

### Root cause

`open_archive` seeks to `footer.index_offset`, calls `read_block`,
and passes the result directly to `decompress_block` →
`parse_index`. It does not check `block.block_type == ZUPT_BLOCK_INDEX`.
The block_type byte is not part of the HMAC input
(`nonce || ciphertext || aad_seq`), so flipping it does not cause
auth failure. The downstream parse succeeds because the index payload
is structurally valid regardless of what the type byte claimed.

### Fix

`src/zupt_format.c` — after `read_block` inside `open_archive`, add
a structural check that rejects any block at `index_offset` whose
`block_type` is not `ZUPT_BLOCK_INDEX`. This makes the byte
`OPAQUE`-class (tamper detected by parser) per PROMPT.md §5.

### Regression test

Covered indirectly by the exhaustive byte-sweep in F-06 verification:
post-fix, byte 1620 of a 1771-byte archive is no longer in the
"silent-accept" set.

### Verification

- Manual: flip byte at `idx_off + 2`, extract — rejected with
  "Error: Corrupted archive".
- `make test` — 61/61 still pass (the existing tamper tests at
  body offsets 200/500 unaffected).

---

## F-08 — Cosmetic archive metadata not covered by any MAC  [STATUS: fixed]
Severity: low (no impact on file contents, keys, or auth posture)
Discovered: 2026-05-19, sprint 2.2.5
Closed: 2026-05-20, sprint 2.3.0
Component: src/zupt_format.c + include/zupt.h (format change v1.4 → v1.5)

### Reproducer (pre-fix)

Exhaustive byte sweep of a 1771-byte `--pq-sdk` v1.4 archive:

```sh
for pos in $(seq 0 1770); do
    cp a.zupt t.zupt
    python3 -c "b=bytearray(open('t.zupt','rb').read()); b[$pos]^=1; open('t.zupt','wb').write(bytes(b))"
    rm -rf out && mkdir out
    (cd out && ./zupt x --pq-sdk ../k.priv ../t.zupt >/dev/null 2>&1)
    [ -f out/input.txt ] && echo "  silent-accept at byte $pos"
done
```

Pre-fix: 86 silent-accept positions, all in header (timestamps, UUID,
reserved bytes, comment offset) and footer informational fields.

### Fix

New 32-byte archive-integrity-trailer (AIT) appended after the footer.
Encrypted modes store `HMAC-SHA256(mac_key, hdr[0..63] || footer[0..23])`.
Plaintext modes store `XXH64(...)` in the first 8 bytes (best-effort
`OPAQUE`-class).

Layout v1.5:  `[hdr 64B][...blocks...][index][footer 32B][AIT 32B]`
Layout v1.4:  `[hdr 64B][...blocks...][index][footer 32B]` (legacy)

Footer bytes 24..31 (`"ZEND"` magic + `u32 footer_version`) are excluded
from the MAC input — both are structurally validated by
`locate_footer_v15` (it rejects bad magic and `footer_version != 1`).
Including them would create a circular dependency where the version
field would need MAC-coverage from a key derivation that itself
depends on the version.

Read path falls back to v1.4 layout if the footer magic isn't found at
EOF-64; encrypted v1.4 extracts emit a stderr downgrade warning.

### Regression test

`tests/test_f08_topmac.sh` — 4 assertions. Builds a v1.5 archive,
tampers at 25 header+footer positions, asserts each is rejected with
the top-MAC error message. Direction 2 (v1.4 backward compat) runs
when `tests/fixtures/zupt-2.2.5` is present.

### Verification

- Post-fix exhaustive byte sweep of a 1803-byte v1.5 `--pq-sdk` archive:
  18 silent-accept positions remaining, all in per-block frame preface
  bytes (codec_id, block_flags, varints, checksum). Opened as F-09.
- `make test` — 65/65 passing (F-08's 4 + 61 existing).
- `make test-asan` `--pq-sdk` roundtrip — byte-exact, clean.
- Backward-compat: v1.4 archive built by 2.2.5 binary extracts cleanly
  via v2.3.0 with the downgrade warning shown.

---

## F-09 — Per-block-header trivia bytes still tamper-tolerant  [STATUS: fixed]
Severity: low (no impact on file contents; closes the last byte-level tamper window)
Discovered: 2026-05-20, sprint 2.3.0
Closed: 2026-05-20, sprint 2.3.1
Component: src/zupt_crypto.c (new _aad primitives), src/zupt_format.c (preface AAD wiring + enc-header strict validation), include/zupt.h (format v1.5 → v1.6, ZUPT_FLAG_AAD_PREFACE)

### Reproducer (pre-fix)

```sh
# Exhaustive sweep on v1.5 PQ-SDK archive (Zupt 2.3.0):
./zupt keygen --sdk -o k.priv
echo "data" > input.txt
./zupt c --pq-sdk k.priv.pub a.zupt input.txt
SZ=$(wc -c < a.zupt)
for pos in $(seq 0 $((SZ-1))); do
    cp a.zupt t.zupt
    python3 -c "b=bytearray(open('t.zupt','rb').read()); b[$pos]^=1; open('t.zupt','wb').write(bytes(b))"
    mkdir out; (cd out && ../zupt x --pq-sdk ../k.priv ../t.zupt >/dev/null 2>&1)
    [ -f out/input.txt ] && echo "  silent-accept at byte $pos"
    rm -rf out
done
# Pre-2.3.1 v1.5 output: 18 silent-accept positions
```

### Root cause

Two distinct subproblems, both closed:

**A. Encrypted-block frame preface unauthenticated.** The per-block HMAC
input was `nonce || ciphertext || aad_seq`. The `(block_type, codec_id,
block_flags, usz, csz, plaintext_xxh64)` preface bytes — read separately
by the parser before reaching the encrypted payload — sat outside MAC
coverage. An attacker could flip them without auth failure.

**B. Encryption-header block fully outside MAC coverage.** The
encryption header is plaintext by necessity (it carries the
key-establishment data needed before any key derivation). It bypasses
the per-block HMAC path entirely (its `block_flags = 0`, no
ZUPT_BFLAG_ENCRYPTED). Its frame preface had no structural validation
beyond magic + length sanity. 17 of the 18 silent-accept positions
were in this block.

### Fix

**For A (v1.6 archives):** New extended-AAD primitives
`zupt_encrypt_buffer_aad` and `zupt_decrypt_buffer_aad` take a
`(aad_extra, aad_extra_len)` pair that prepends to the MAC input:
`aad_extra || nonce || ciphertext || aad_seq`. The original
`zupt_encrypt_buffer` / `zupt_decrypt_buffer` are now thin wrappers
passing `aad_extra=NULL,len=0`, preserving byte-exact MAC output for
v1.4 and v1.5 archives.

Callers in `src/zupt_format.c` build a 29-byte canonical preface AAD
from fixed-width LE serialization of `(block_type, codec_id,
block_flags, usz, csz, plaintext_xxh64)`. Critically NOT the on-disk
varint encoding for sizes, because varints have multiple valid
encodings of the same logical value — a non-canonical varint would
produce a different MAC despite encoding the same archive.

The policy is anchored at archive level: `ZUPT_FLAG_AAD_PREFACE` (bit
9 in `global_flags`) signals "this archive uses extended AAD". The
flag itself is MAC-protected by the v1.5 archive-integrity-trailer
(F-08), so an attacker cannot flip it without auth-fail at AIT
verification.

Read-side downgrade protection: when `keyring.use_preface_aad == 1`
and the caller is the `_aad` decrypt, only the extended-AAD MAC is
checked — no v1/v2 fallback. The flag is propagated from
`global_flags` AFTER the AIT has authenticated the header.

**For B (enc-header strict validation):** Same pattern as F-07 of
v2.2.5 (which closed the index-block `block_type`). `read_enc_header`
now requires:

- `block_type == ZUPT_BLOCK_ENC_HEADER`
- `codec_id == ZUPT_CODEC_STORE` (envelope never compressed)
- `block_flags == 0` (envelope has its own crypto)
- `compressed_size == uncompressed_size` (no length games)
- `plaintext_xxh64 == zupt_xxh64(payload, csz, 0)` (actual content match)

### Regression test

`tests/test_f09_preface.sh` runs the full exhaustive byte sweep on
a fresh v1.6 PQ-SDK archive every `make test` invocation. Pre-fix:
~18 silent-accepts. Post-fix: **0 of ~1827 byte tampers
silent-accepted**.

### Cross-version compatibility (verified)

- **v2.3.1 reads v1.5 (v2.3.0) archives byte-exact** — `decompress_block`
  sees `keyring.use_preface_aad == 0` and calls the legacy decrypt
  path. The legacy `zupt_decrypt_buffer` now delegates to
  `zupt_decrypt_buffer_aad` with `aad_extra_len=0`, which preserves
  the exact pre-v1.6 behaviour.
- **v2.3.0 cannot read v1.6 archives** — rejects with auth-fail
  because the MAC includes preface AAD bytes v2.3.0's decrypt doesn't
  feed in. Clean rejection (not silent corruption). This is intended:
  v2.3.0 readers can't ignore the new flag bit without losing F-09's
  tamper protection.
- v1.4 archives continue to extract under v2.3.1 with the F-08
  downgrade-warning stderr line, unchanged.

### Verification

- `make test-f09-preface` (wired into `make test`): exhaustive sweep
  on 1827-byte v1.6 PQ-SDK archive — **0/1827 silent-accepts**.
- `make test` — all 8 suites green.
- `make test-vectors` — 14/14.
- `make test-f06` — 2000/2000 (the F-06 fix lives in the shared
  `_aad` implementation, so the legacy wrapper path inherits it).
- `make test-asan` `--pq-sdk` byte-exact roundtrip — clean.
- 50× audit-suite stress — 50/50 green.
- Strict GCC + Clang warning matrix — clean.

---



## F-10 — Password-mode KDF default upgraded to Argon2id  [STATUS: fixed]
Severity: N/A (security improvement, not a bug fix)
Discovered: 2026-05-20, sprint 2.4.1 (planned work, not a found defect)
Closed: 2026-05-20, sprint 2.4.1
Component: src/zupt_format.c (write_enc_header password branch), src/zupt_main.c (CLI), include/zupt.h

### Rationale

PBKDF2-SHA256 with 600 000 iterations is OWASP-acceptable but
sequential-time-hard only. Argon2id (OWASP's current
recommendation) is also memory-hard, raising the cost of
GPU/ASIC-accelerated brute force by orders of magnitude. Zupt
already shipped the Argon2id path (`zupt_sdk_password_encrypt_init`,
enc_type byte 0x04, dispatched via the existing read-side switch)
since the libzuptsdk integration; only the write-side default was
still PBKDF2.

### Fix

`write_enc_header` password branch checks `opts->kdf_legacy_pbkdf2`.
Default 0 = Argon2id (33-byte enc-header: `[0x04][16B salt][16B nonce]`).
Set to 1 by `--kdf pbkdf2` for legacy compatibility (53-byte
PBKDF2 enc-header: `[0x01][32B salt][16B nonce][4B iter]`).

The downstream per-block ciphertext pipeline is identical in both
modes (same kr->enc_key, mac_key, base_nonce flow into AES-256-CTR
+ HMAC-SHA256 + F-09 preface-AAD). F-09 byte-level tamper detection
carries over unchanged.

### Backward compatibility

v2.4.0-and-older readers already supported Argon2id-mode reading
via the existing `enc_type` dispatch — `zupt_sdk_password_decrypt_init`
was already linked. So **v2.4.0 readers extract v2.4.1
Argon2id-default archives without modification**, verified on a
fresh v2.4.0 build extracting a v2.4.1 default archive byte-exact.

### Regression test

`tests/test_f10_kdf_default.sh` — 10 assertions:
1. Default `-p` → enc_type = 0x04
2. Default stderr names "Argon2id"
3. `--kdf pbkdf2` → enc_type = 0x01
4. `--kdf pbkdf2` stderr names "PBKDF2"
5. Argon2id archive roundtrips byte-exact
6. PBKDF2 archive roundtrips byte-exact
7. Argon2id wrong-password rejected
8. PBKDF2 wrong-password rejected
9. Explicit `--kdf argon2id` → enc_type = 0x04
10. `--kdf garbage` rejected at parse time

Wired into `make test`.

### Verification

- `make test` — 9 suites green, F-10 10/10.
- `make test-f06` — 2000/2000 (the F-06 fix applies to both KDF
  paths since they share the per-block decrypt code).
- ASAN Argon2id roundtrip on `include/` — byte-exact, clean.
- §3.5 byte sweep on 369-byte Argon2id archive: 0 undetected
  across header (0-63) and footer+AIT (last 80); body sampled
  every 4 bytes also clean.

---

## F-11 — "Tampered" error message on wrong-password extract  [STATUS: fixed]
Severity: low (UX, not security; misleading wording on a common user error)
Discovered: 2026-05-20, sprint 2.4.1
Closed: 2026-05-20, sprint 2.4.2
Component: src/zupt_format.c (open_archive AIT-fail path, read_enc_header SDK-init-fail paths), src/zupt_disk.c (zupt_disk_restore AIT-fail path)

### Symptom (pre-2.4.2)

Wrong password on extract produced:

```
Error: archive-integrity-trailer (top-MAC) verification failed.
       The archive header or footer has been tampered with.
Error: Authentication failed (wrong password?)
```

The "header or footer has been tampered with" framing made users
think the archive was corrupted. The wording was inherited from the
actual-tamper case (both share the AIT-verify code path; wrong
password → wrong mac_key → AIT mismatch).

### Fix

Encrypted-archive AIT failure and SDK envelope decryption failure
print the same generic line by default:

```
Error: Authentication failed (wrong key, wrong password, or tampered archive).
```

Three code paths updated to emit identical wording:

- `open_archive()` AIT-verify failure on encrypted archives
- `read_enc_header()` SDK-v2 PQ envelope init failure
- `read_enc_header()` Argon2id password init failure

The `--verbose` flag re-enables the detailed top-MAC / SDK-step
wording for debugging. Plaintext archives (where the failure can
only be corruption/tamper, no key involved) keep their detailed
XXH64-failure wording.

### Why the verbal probe-oracle property matters

If different wrong-key failure causes produced different default
messages, an attacker who can issue extract attempts (e.g. against
an encrypted backup they stole) would learn which check failed
first — wrong password vs. wrong PQ key vs. actual tamper — even
when all three should be observationally equivalent. The collapsed
message removes that distinction by construction. Timing is
unchanged: `ait_verify` always runs the HMAC, branchless return,
same as F-08.

### Regression test

`tests/test_f11_authfail_message.sh` — 12 assertions:

1. Argon2id wrong-pw default: generic auth-fail line
2. Argon2id wrong-pw default: no standalone "tampered" claim
3. Argon2id wrong-pw default: no top-MAC technical detail
4. Argon2id wrong-pw --verbose: top-MAC detail shown
5. Argon2id wrong-pw --verbose: generic line still present
6. PBKDF2 wrong-pw default: generic auth-fail line
7. Actual encrypted-header tamper: SAME generic message as wrong-pw
8. Actual encrypted-header tamper: extract correctly refused
9. Plaintext tamper: detailed XXH64-failure message kept
10. Plaintext tamper: doesn't conflate with key-mode wording
11. Correct password: clean extract preserved (no regression)
12. PQ-SDK wrong-key: generic auth-fail line

Wired into `make test`.

### Verification

- `make test` — 10 suites green, F-11 12/12.
- `make test-vectors` — 14/14.
- `make test-f06` — 2000/2000.
- ASAN `--pq-sdk` byte-exact roundtrip on `include/` — clean.
- 50× audit-suite stress — 50/50.
- Strict GCC + Clang warning matrix — clean.

### Files touched

- `src/zupt_format.c` — 3 error-message sites
- `src/zupt_disk.c` — 1 error-message site
- `tests/test_f11_authfail_message.sh` — new
- `tests/test_f08_topmac.sh` — updated to accept new wording (the
  detailed "top-MAC" string now requires `--verbose`)

---

## F-12 — Encrypted archive comments  [STATUS: fixed]
Severity: N/A (new feature, not a defect)
Discovered: 2026-05-20, sprint 2.4.3 (planned work)
Closed: 2026-05-20, sprint 2.4.3
Component: include/zupt.h (ZUPT_BLOCK_COMMENT, ZUPT_MAX_COMMENT_LEN, options fields), src/zupt_format.c (write_comment_block, open_archive reader, info/extract display), src/zupt_main.c (-c / --comment-file parsers)

### Use case

The `comment_offset` field has been present in `zupt_archive_header_t`
since v1.0 but was unused. F-12 wires it up so users can embed
free-form UTF-8 metadata that travels with the archive — purpose
notes, customer IDs, restore instructions, etc.

### Design

New block type `ZUPT_BLOCK_COMMENT = 0x05` written between the last
data block and the central index. Block layout is the same as a
data block (magic + type + codec=STORE + flags + sizes +
plaintext-XXH64 + payload). `hdr.comment_offset` points to the
block; `0` means no comment.

### Security properties

- **Comment payload tamper**: per-block HMAC catches it. Comment
  blocks use the F-09 preface AAD when v1.6 is in effect, so the
  preface bytes (block_type, codec, flags, sizes, XXH64) are also
  bound into the MAC. `aad_seq = 0xFFFFFFFFFFFFFFFE` (one less than
  the index sentinel; cannot collide with file-block aad_seqs which
  encode `(fi+1, block_seq)` in upper/lower 32-bit halves and are
  bounded above by `0xFFFFFFFF00000000`).
- **comment_offset pointer tamper**: header field lives in
  `hdr[44..51]`, covered by the v1.5 AIT. Tampering → auth-fail
  at open time, before the block is ever read.
- **Comment plaintext disclosure**: encrypted archives keep the
  comment encrypted on disk; only `zupt x` with the right key
  decrypts and displays it. `zupt info` reports presence only.

### Format compatibility

No format-minor bump (still v1.6). v2.4.2 readers seek to file
data via the central index's `first_block_offset` values, not
sequentially, so a comment block sitting between data and index
is skipped. v2.4.2 ignores `comment_offset` entirely and extracts
v2.4.3 archives byte-exact — they just don't display the comment.

Verified by extracting an example v2.4.3 archive with a v2.4.2
binary (built from `zupt-2.4.2.tar.gz`).

### Regression test

`tests/test_f12_comment.sh` — 11 assertions across plaintext,
Argon2id, PBKDF2, and PQ-SDK modes:

1. plaintext: comment roundtrips
2. Argon2id: comment roundtrips
3. PBKDF2: comment roundtrips
4. PQ-SDK: comment roundtrips
5. `info` does NOT leak the encrypted comment plaintext
6. `info` reports comment presence
7. tampering the comment block payload is rejected
8. tampering `hdr.comment_offset` is rejected
9. no-comment archive shows no `Comment:` line in `info`
10. `--comment-file` reads from disk
11. empty `-c ""` is treated as no-comment

Wired into `make test`.

### Verification

- §3.5 exhaustive byte sweep on PQ-SDK archive **with** a comment
  block (1878 bytes total, ~75 bytes larger than the v2.3.1
  baseline): **0/1878 silent acceptances**. All new bytes are
  MAC-covered.
- `make test` — 11 suites all green.
- `make test-vectors` 14/14.
- `make test-f06` 2000/2000.
- ASAN PQ-SDK byte-exact roundtrip on `include/` with a comment —
  clean.
- Strict GCC + Clang clean (one ISO C99 string-length warning hit
  during this sprint; fixed by splitting the help text into two
  `fprintf` calls).
- 50× audit-suite stress — 50/50.
- Cross-version: v2.4.2 extracts a v2.4.3 archive byte-exact (the
  comment block is simply not visited).

### Caveats

- `--comment-file` strips trailing newlines so editor end-of-file
  newlines don't cause `comment_file != roundtrip_decode` in tests.
  Intentional; documented in the help text.
- `info` shows only presence, not content, even for plaintext
  archives. Could be relaxed in a future release if there's demand;
  current behaviour is the safer default.

