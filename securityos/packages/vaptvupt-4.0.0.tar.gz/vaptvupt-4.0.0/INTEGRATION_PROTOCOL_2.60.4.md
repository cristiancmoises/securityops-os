# INTEGRATION PROTOCOL — VaptVupt tool 3.8.0 → 3.9.0
# Codec engine upgrade 2.53.3 → 2.60.4 (+ BCJ), stack alignment
# Operator: Cristian Cezar Moisés · 2026-06-10 · status: EXECUTING

## Mission
Integrate canonical VaptVupt codec v2.60.4 into the backup tool, take the
two upstream decode-safety fixes, expose the BCJ executable-ratio win,
prove wire/back compatibility with real pre-upgrade archives, keep every
existing guarantee green, and ship source + all distro packages.

## Inputs (verified sha256 against stack SHA256SUMS)
- vaptvupt-2.60.4-src.tar.gz        → engine + headers to vendor
- libpqvaptvupt-0.6.0 / libvaptvupt-1.6.1 → see Scope decisions
- deploy-kit                         → release notes, COMPARISON, prebuilts (reference only)

## Scope decisions (explicit, with reasons)
1. IN: vendor codec 2.60.4 engine verbatim: vv_ans.c vv_decoder.c
   vv_encoder.c vv_huffman.c vv_simd.c vv_xxh64.c + NEW vv_bcj.c, and
   headers vaptvupt.h vv_ans.h vv_bcj.h vv_huffman.h vv_platform.h.
   KEEP the tool-local wrapper vaptvupt_api.{c,h} (checksum=0 +
   SKIP_CHECKSUM because the outer HMAC authenticates; format_v2 gating).
   All four call sites (vv_compress, vv_compress_bound, vv_decompress,
   vv_default_options) survive in 2.60.4 unchanged — verified by header diff.
2. IN: enable opts.filter_auto=1 for BALANCED and EXTREME (executable
   sniffing; no-op on non-executables). NOT for ULTRA_FAST (speed mode,
   minimal-change discipline). Forward-compat note required: blocks where
   a BCJ filter fired need codec ≥2.54.0 (tool ≥3.9.0) to decode.
3. IN: keep ZUPT_VV_DECODE_SLACK 64 even though 2.60.4 fixes the root
   cause (2.60.2 + 2.60.4 OOB writes). Defense in depth; cost ≈ 0.
4. OUT: libpqvaptvupt as the tool's SDK. It is a sealed-box-only API
   (pqvv_keygen/seal/open), no password KDF, own wire magic and key
   sizes — it cannot replace vendor/zuptsdk's easy_derive_key (password
   mode) or the existing --pq-sdk format without breaking every existing
   archive/keyfile. Candidate for a future --pq-sdk v3 backend; not this
   release. The Argon2id-explicit-params item stays blocked on the SDK.
5. OUT: libvaptvupt (multi-language bindings) — irrelevant to the C tool.

## Invariants (any violation = stop and fix, never ship around)
- Wire format v1.6, magic 5A 55 50 54 1A 00. No archive format change.
- Pre-upgrade archives (created by the 3.8.0 binary, all modes incl.
  encrypted + PQ) extract byte-exact under the new binary.
- -Wall -Wextra -Werror clean, GCC; strict-9 set stays clean.
- All 24 suites green (CT suite may be INCONCLUSIVE under contention by
  design). ASan clean on the smoke path.
- Licenses unchanged: tool AGPL-3.0-or-later, codec GPL-3.0-or-later.
- Every performance claim in docs: measured on the stated box or [ESTIMATED].

## Verification gates, in order
G1 baseline: build untouched 3.8.0; regenerate fixtures (text, binary=ELF,
   source, redundant, random) and reference archives (L1/L5/L9, store,
   password, PQ) with it. Record sha256 of originals.
G2 swap: engine files + headers replaced; wrapper + Makefile updated
   (vv_bcj.o); strict build clean.
G3 function: all-mode roundtrips; every G1 reference archive byte-exact;
   tamper + wrong-key still rejected.
G4 codec semantics: BCJ fires on ELF fixture (flag bit2 set, ratio delta
   measured, roundtrip exact); UF+format_v2 constraint re-probed against
   2.60.4 and the wrapper comment updated to the measured truth.
G5 suite: full make test; ASan smoke; test_vectors 16/0.
G6 release: version 3.9.0 across zupt.h, man, 6 packaging files; Debian +
   openSUSE changelog entries; CHANGELOG/ROADMAP/AUDIT/README/BENCHMARKS
   updated with measured numbers; dist tarball reproducible, 0 stale .o;
   clean-room build from tarball passes G3 spot checks.
G7 ship: deb, rpm, AppImage, AppDir, GUI×4 (1.3.0), openSUSE bundle,
   SHA256SUMS.txt → /mnt/user-data/outputs + present.

## Honesty clauses
- The 2.60.4 fix is upstream work: credit it as such in CHANGELOG; the
  tool release takes it, it does not claim it.
- BCJ numbers: measure on the ELF fixture on this box; the upstream
  "+3–7%" figure is upstream's, cite it as upstream-measured.
- If any gate cannot pass in this environment, say which, why, and what
  was shipped instead. No silent scope cuts.
